from flask import Flask, render_template, request, redirect, url_for
import mysql.connector

app = Flask(__name__)

# DB connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="20040630",  # replace this
    database="receipt_db"
)
cursor = db.cursor()

@app.route('/', methods=['GET'])
def index():
    # Show form and receipt history
    cursor.execute("SELECT id, payer, language, total, date FROM receipts ORDER BY id DESC")
    history = cursor.fetchall()
    return render_template('index.html', history=history)

@app.route('/submit', methods=['POST'])
def submit():
    payer = request.form['payer']
    items_raw = request.form['items']
    lang = request.form['language']
    items = items_raw.strip().split('\n')

    total = 0
    for line in items:
        name, values = line.split(":")
        price, discount = map(float, values.split(","))
        total += price - discount

    # Insert into DB
    cursor.execute(
        "INSERT INTO receipts (payer, language, total) VALUES (%s, %s, %s)",
        (payer, lang, total)
    )
    db.commit()

    # Redirect to receipt.html with query parameters
    return redirect(url_for('receipt', payerName=payer, items=items_raw, language=lang))

@app.route('/receipt')
def receipt():
    return render_template('receipt.html')
    
if __name__ == '__main__':
    print("🚀 Running app...")
    app.run(debug=True)
